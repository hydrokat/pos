@extends('layouts.guest')

@section('content')

    About the developer

@stop

@section('assets')

@stop