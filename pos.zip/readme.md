POS built with Laravel
